SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season',
    b_3B_R AS 'Triples'
FROM statsA
WHERE b_3B_R != "NULL" AND b_3B_R > 0
ORDER BY b_3B_R DESC;