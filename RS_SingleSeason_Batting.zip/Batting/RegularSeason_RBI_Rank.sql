SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season',
    b_RBI_R AS 'RBIs'
FROM statsA
WHERE b_RBI_R != "NULL" AND b_RBI_R > 0
ORDER BY b_RBI_R DESC;