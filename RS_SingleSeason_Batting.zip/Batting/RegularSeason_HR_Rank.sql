SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season', 
    b_Games_R AS 'Games',
    b_HR_R AS 'Homeruns'
FROM statsA
WHERE b_HR_R != " NULL" AND b_HR_R > 0
ORDER BY b_HR_R DESC;