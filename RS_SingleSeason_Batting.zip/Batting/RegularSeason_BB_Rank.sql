SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season',
    b_BB_R AS 'Base on Balls'
FROM statsA
WHERE b_BB_R != "NULL" AND b_BB_R > 0
ORDER BY b_BB_R DESC;