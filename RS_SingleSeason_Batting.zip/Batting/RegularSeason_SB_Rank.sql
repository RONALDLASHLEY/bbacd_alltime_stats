SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season', 
    b_Games_R AS 'Games',
    b_SB_R AS 'Stolen Bases'
FROM statsA
WHERE b_SB_R != " NULL" AND b_SB_R > 0
ORDER BY b_SB_R DESC;