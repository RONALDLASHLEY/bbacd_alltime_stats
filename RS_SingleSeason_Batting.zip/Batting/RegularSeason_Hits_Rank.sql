SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season',  
    b_Games_R AS 'Games', 
    b_Hits_R AS 'Hits'
FROM statsA
WHERE b_AB_R != "NULL" AND b_Hits_R > 0
ORDER BY b_Hits_R DESC;