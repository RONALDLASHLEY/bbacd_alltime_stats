SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season',
    b_2B_R AS 'Doubles'
FROM statsA
WHERE b_2B_R != "NULL" AND b_2B_R > 0
ORDER BY b_2B_R DESC;