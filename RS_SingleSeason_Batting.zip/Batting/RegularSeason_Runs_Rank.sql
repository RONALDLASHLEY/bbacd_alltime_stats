SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season',
    b_Runs_R AS 'Runs'
FROM statsA
WHERE b_Runs_R != "NULL" AND b_Runs_R > 0
ORDER BY b_Runs_R DESC;