SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season', 
    b_BA_R AS 'Batting Average'
FROM statsA
WHERE b_AB_R > 20 AND b_AB_R != "NULL"
ORDER BY b_BA_R DESC;