SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season', 
    p_Inn_R AS 'Innings Pitched', 
    p_ERA_R AS 'ERA'
FROM statsA
WHERE p_ERA_R != " NULL" AND p_Inn_R > 15
ORDER BY p_ERA_R ASC;