SELECT name AS 'Name', 
    class AS 'Class', 
    season AS 'Season', 
    p_Inn_R AS 'Innings',
    p_K_R AS 'Strikeouts'
FROM statsA
WHERE p_K_R != " NULL" AND p_K_R > 0
ORDER BY p_K_R DESC;