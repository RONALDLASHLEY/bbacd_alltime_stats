SELECT season_records.season AS 'Season', 
	season_records.Division AS 'Division',
	SUM(p_Hits_R) AS 'Hits Allowed',
	SUM(p_BB_R) AS 'Walks',
	SUM(p_Runs_R) AS 'Runs',
	SUM(p_ER_R) AS 'Earned Runs',
	SUM(p_K_R) AS 'Strikeouts'
FROM statsA
INNER JOIN season_records
ON season_records.season = statsA.season
GROUP BY statsA.season
ORDER BY statsA.season;