SELECT season AS 'Season', 
	SUM(b_Hits_R) AS 'Hits',
	SUM(b_2B_R) AS 'Doubles',
	SUM(b_3B_R) AS 'Triples',
	SUM(b_HR_R) AS 'Homeruns',
	SUM(b_BB_R) AS 'Triples',
	SUM(b_RBI_R) AS 'RBIs',
	SUM(b_Runs_R) AS 'Runs'
FROM statsA
WHERE b_AB_R != 'NULL'
GROUP BY season
ORDER BY SUM(b_Hits_R) DESC;
