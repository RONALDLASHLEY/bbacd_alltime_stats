SELECT season_records.season AS 'Season', 
	season_records.Division AS 'Division',
	SUM(p_Hits_P) AS 'Hits Allowed',
	SUM(p_BB_P) AS 'Walks',
	SUM(p_Runs_P) AS 'Runs',
	SUM(p_ER_P) AS 'Earned Runs',
	SUM(p_K_P) AS 'Strikeouts'
FROM statsA
INNER JOIN season_records
ON season_records.season = statsA.season
WHERE season_records.Wins_Playoffs != 'NULL' AND 
	season_records.Losses_Playoffs != 'NULL'
GROUP BY statsA.season
ORDER BY statsA.season;