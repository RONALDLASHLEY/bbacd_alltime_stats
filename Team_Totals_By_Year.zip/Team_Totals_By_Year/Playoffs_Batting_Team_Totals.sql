SELECT season AS 'Season', 
	SUM(b_Hits_P) AS 'Hits',
	SUM(b_AB_P) AS 'At-Bats',
	SUM(b_2B_P) AS 'Doubles',
	SUM(b_3B_P) AS 'Triples',
	SUM(b_HR_P) AS 'Homeruns',
	SUM(b_BB_P) AS 'Triples',
	SUM(b_RBI_P) AS 'RBIs',
	SUM(b_Runs_P) AS 'Runs'
FROM statsA
WHERE b_AB_P != 'NULL'
GROUP BY season
ORDER BY SUM(b_Hits_P) DESC;