SELECT name AS 'Name', 
    class AS 'Class', 
    (min(season) || '-' || max(season)) AS 'Seasons',
    SUM(b_Hits_R) AS 'Hits'
FROM statsA
WHERE b_AB_R != "NULL" 
GROUP BY name
ORDER BY SUM(b_Hits_R) DESC;