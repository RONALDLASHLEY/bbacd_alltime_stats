SELECT name AS 'Name', 
    class AS 'Class', 
    (min(season) || '-' || max(season)) AS 'Seasons',
    SUM(b_SB_R) AS 'Stolen Bases'
FROM statsA
WHERE b_SB_R != "NULL" 
GROUP BY name
ORDER BY SUM(b_SB_R) DESC;