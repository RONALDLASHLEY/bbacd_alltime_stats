SELECT name AS 'Name', 
    class AS 'Class', 
    (min(season) || '-' || max(season)) AS 'Seasons',
    SUM(b_RBI_R) AS 'RBIs'
FROM statsA
WHERE b_RBI_R != "NULL" 
GROUP BY name
ORDER BY SUM(b_RBI_R) DESC;