SELECT name AS 'Name', 
    class AS 'Class', 
    (min(season) ||  '-' || max(season)) AS 'Seasons',
    SUM(b_Hits_R) / SUM(b_AB_R) AS 'Batting Average'
FROM statsA
WHERE b_AB_R != "NULL" 
    AND SUM(b_AB_R) >= 50
GROUP BY name
ORDER BY SUM(b_AB_R) / SUM(b_Hits_R) DESC;