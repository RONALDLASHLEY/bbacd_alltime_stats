SELECT name AS 'Name', 
    class AS 'Class', 
    (min(season) || '-' || max(season)) AS 'Seasons',
    SUM(b_BB_R) AS 'Stolen Bases'
FROM statsA
WHERE b_BB_R != "NULL" 
GROUP BY name
ORDER BY SUM(b_BB_R) DESC;